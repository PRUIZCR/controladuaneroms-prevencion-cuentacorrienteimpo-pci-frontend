
import { Routes,RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { PagesComponent } from './pages.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GraficaComponent } from './grafica/grafica.component';
import { ProgressComponent } from './progress/progress.component';

const routes:Routes=[
    {path:'cpi',
        component:PagesComponent,
        children:[
          { path:'',component:DashboardComponent,data:{titulo:'Dashboard'}},
          { path:'progress',component:ProgressComponent,data:{titulo:'ProgressBar'}},
          { path:'grafica',component:GraficaComponent,data:{titulo:'Grafica #1'}},
          { path:'**', redirectTo:'/cpi',pathMatch:'full'},

      ]
    },
];
@NgModule({

    imports: [ RouterModule.forChild(routes) ],
    exports: []
})
export class PagesRoutingModule{}

