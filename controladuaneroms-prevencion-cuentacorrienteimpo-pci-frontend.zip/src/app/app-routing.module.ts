import { PagesComponent } from './pages/pages.component';
import { NopagefoundComponent } from './pages/nopagefound/nopagefound.component';
import { ProgressComponent } from './pages/progress/progress.component';
import { GraficaComponent } from './pages/grafica/grafica.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [


{ path: '',
component: PagesComponent,
children:[
  {path:'dashboard',component:DashboardComponent},
  {path:'progress',component:ProgressComponent},
  {path:'grafica',component:GraficaComponent},
  { path:'',redirectTo:'/dashboard',pathMatch:'full'},
 ]
},

{ path:'**',component:NopagefoundComponent},


];

@NgModule({
  declarations:[],
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
